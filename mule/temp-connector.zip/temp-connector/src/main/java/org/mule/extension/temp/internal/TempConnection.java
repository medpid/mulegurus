package org.mule.extension.temp.internal;

import org.lightcouch.CouchDbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class represents an extension connection just as example (there is no
 * real connection with anything here c:).
 */
public final class TempConnection {

	private final Logger LOGGER = LoggerFactory.getLogger(TempConnection.class);

	
	private static int count = 1;
	private CouchDbClient dbClient = null;

	public CouchDbClient getDbClient() {
		return dbClient;
	}

	public TempConnection(String hostName, int port, String username, String password, String dbName) {
		LOGGER.info(" TempConnection() ----------------> COUNT :: " + count++);
		this.dbClient = new CouchDbClient(dbName, true, "http", hostName, port, username, password);
		LOGGER.info(" TempConnection() ----------------> Client :: " + this.dbClient);

	}

	public void invalidate() {
		try {
			dbClient.close();
		} catch (Exception e) {
			LOGGER.error("Failed to Close, ", e);
		}

		LOGGER.info("TempConnection().invalidate() is being called.");
	}
}
