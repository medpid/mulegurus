package org.mule.extension.temp.internal;

import org.mule.runtime.extension.api.annotation.Operations;
import org.mule.runtime.extension.api.annotation.connectivity.ConnectionProviders;
import org.mule.runtime.extension.api.annotation.param.Parameter;
import org.mule.runtime.extension.api.annotation.param.ParameterGroup;
import org.mule.runtime.extension.api.annotation.param.display.DisplayName;
import org.mule.runtime.extension.api.annotation.param.display.Placement;
import org.mule.runtime.extension.api.annotation.param.display.Summary;

/**
 * This class represents an extension configuration, values set in this class
 * are commonly used across multiple operations since they represent something
 * core from the extension.
 */
@Operations(TempOperations.class)
@ConnectionProviders(TempConnectionProvider.class)
public class TempConfiguration {

	@Parameter
	@Placement(order = 2, tab = "General")
	@DisplayName("Configuration ID")
	@Summary("Identification of the configuiration")
	private String configId;

	@Parameter
	@Placement(order = 1, tab = "General")
	@DisplayName("Data Channel")
	@Summary("Identification of the channel")
	private String channel;

	public String getConfigId() {
		return configId;
	}

	public String getChannel() {
		return channel;
	}

}
