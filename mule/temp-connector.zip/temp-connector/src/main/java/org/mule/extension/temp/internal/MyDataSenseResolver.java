/**
 * 
 */
package org.mule.extension.temp.internal;

import java.util.HashMap;

import org.mule.metadata.api.builder.BaseTypeBuilder;
import org.mule.metadata.api.model.MetadataFormat;
import org.mule.metadata.api.model.MetadataType;
import org.mule.runtime.api.metadata.MetadataContext;
import org.mule.runtime.api.metadata.resolving.InputTypeResolver;
import org.mule.runtime.api.metadata.resolving.OutputTypeResolver;

/**
 * @author vasuk
 *
 */
public class MyDataSenseResolver implements InputTypeResolver<String>, OutputTypeResolver<String> {

    @Override
    public String getCategoryName() {
        return "MyDataSenseResolver";
    }

    @Override
    public MetadataType getInputMetadata(MetadataContext metadataContext, String entityKeyId){
        return new BaseTypeBuilder(MetadataFormat.JAVA).numberType().build();
    }

    @Override
    public MetadataType getOutputType(MetadataContext metadataContext, String entityKeyId){
        return metadataContext.getTypeLoader().load(HashMap.class);
    }

	@Override
	public String getResolverName() {
		return InputTypeResolver.super.getResolverName();
	}
}