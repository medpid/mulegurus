package org.mule.extension.temp.internal;

import static org.mule.runtime.extension.api.annotation.param.MediaType.ANY;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.lightcouch.Response;
import org.mule.runtime.api.meta.ExpressionSupport;
import org.mule.runtime.extension.api.annotation.Expression;
import org.mule.runtime.extension.api.annotation.param.Config;
import org.mule.runtime.extension.api.annotation.param.Connection;
import org.mule.runtime.extension.api.annotation.param.MediaType;
import org.mule.runtime.extension.api.annotation.param.Optional;
import org.mule.runtime.extension.api.annotation.param.Parameter;
import org.mule.runtime.extension.api.annotation.param.ParameterGroup;
import org.mule.runtime.extension.api.annotation.param.display.DisplayName;
import org.mule.runtime.extension.api.annotation.param.display.Placement;
import org.mule.runtime.extension.api.annotation.param.display.Summary;

/**
 * This class is a container for operations, every public method in this class
 * will be taken as an extension operation.
 */
public class TempOperations {
	
	@Parameter
	@Optional(defaultValue = "DEFAULT")
	@DisplayName("PERSON LABEL")
	@Expression(ExpressionSupport.REQUIRED)
	@Placement(order= 1)
	private String person;

	/**
	 * Example of an operation that uses the configuration and a connection instance
	 * to perform some action.
	 */
	@MediaType(value = ANY, strict = false)
	public String retrieveInfo(@Config TempConfiguration configuration, @Connection TempConnection connection) {
		System.out.println("PERSON DATA :" + person);
		return "Using Configuration [" + configuration.getConfigId() + "] with Connection id [5984]";
	}

	/**
	 * Example of a simple operation that receives a string parameter and returns a
	 * new string message that will be set on the payload.
	 */
	@MediaType(value = ANY, strict = false)
	@DisplayName("Save to Couch DB")
	@Summary("This is summary demo.")
	public InputStream saveObject(@ParameterGroup(name = "Person Properties") Person person, @Config TempConfiguration configuration, @Connection TempConnection connection) {
		System.out.println("SAY HI Connection: " + configuration.getChannel());
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("firstName", person.getFirstName());
		map.put("lastName", person.getLastName());
		map.put("dateOfBirth", person.getDateOfBirth());
		map.put("address", person.getAddress());
		Response result = connection.getDbClient().save(map);
		String id = result.getId();
		InputStream output = connection.getDbClient().find(id);
		return output;
	}

}
