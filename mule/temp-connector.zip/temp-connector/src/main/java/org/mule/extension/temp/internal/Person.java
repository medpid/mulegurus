/**
 * 
 */
package org.mule.extension.temp.internal;

import org.mule.runtime.extension.api.annotation.param.Parameter;
import org.mule.runtime.extension.api.annotation.param.display.DisplayName;
import org.mule.runtime.extension.api.annotation.param.display.Text;

/**
 * @author vasuk
 *
 */
public class Person {

	@Parameter
	@DisplayName("First Name")
	private String firstName;

	@Parameter
	@DisplayName("Last Name")
	private String lastName;

	@Parameter
	@DisplayName("Date Of Birth")
	private String dateOfBirth;

	@Parameter
	@DisplayName("Address")
	@Text
	private String address;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
