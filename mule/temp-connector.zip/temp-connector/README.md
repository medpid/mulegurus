# Temp Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>com.mule.exp</groupId>
<artifactId>temp-connector</artifactId>
<version>1.0.0-SNAPSHOT</version>
<classifier>mule-plugin</classifier>
```
